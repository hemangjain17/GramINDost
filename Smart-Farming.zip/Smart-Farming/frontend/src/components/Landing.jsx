import React from 'react';
import './Landing.css'; // Make sure to create this CSS file in the same directory
import Navbar from './Navbar';
const Landing = () => {
  return (
    <>
    <div className='landing-box'>
        <Navbar />
        <div className="landing-container"> 
                   
        </div>
    </div>
    </>
  );
};

export default Landing;
